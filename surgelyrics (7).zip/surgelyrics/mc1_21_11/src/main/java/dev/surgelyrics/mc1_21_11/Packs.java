package dev.surgelyrics.mc1_21_11;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Surge Client texture packs (clear lava, low shield, PvP swords and armor). They ship inside the jar and are copied into
 * the game's resourcepacks folder, so they show up in Options > Resource Packs like any other pack and stack freely.
 */
final class Packs {
    private Packs() {}

    static final String[] FILES = {
            "SurgeClient-ClearLava.zip", "SurgeClient-LowShield.zip",
            "SurgeClient-Swords-Crimson.zip", "SurgeClient-Swords-Frost.zip", "SurgeClient-Swords-Shadow.zip", "SurgeClient-Swords-Neon.zip",
            "SurgeClient-Armor-Crimson.zip", "SurgeClient-Armor-Frost.zip", "SurgeClient-Armor-Shadow.zip", "SurgeClient-Armor-Neon.zip"};
    static final String[] LABELS = {"Clear Lava", "Low Shield", "Crimson", "Frost", "Shadow", "Neon", "Crimson", "Frost", "Shadow", "Neon"};
    static final String[] DESC = {
            "Bright, clean lava that is easy to read.",
            "Shield sits lower and smaller in first person.",
            "Crimson swords, all six tiers.", "Frost swords, all six tiers.", "Shadow swords, all six tiers.", "Neon swords, all six tiers.",
            "Crimson diamond and netherite armor.", "Frost diamond and netherite armor.",
            "Shadow diamond and netherite armor.", "Neon diamond and netherite armor."};

    static Path dir() { return FabricLoader.getInstance().getGameDir().resolve("resourcepacks"); }

    /** Copies any pack that is missing (or an older size) into the resourcepacks folder. force = copy them all again. */
    static void install(boolean force) {
        try {
            Files.createDirectories(dir());
            for (String name : FILES) {
                try (InputStream in = Packs.class.getResourceAsStream("/assets/surgelyrics/packs/" + name)) {
                    if (in == null) continue;
                    byte[] data = in.readAllBytes();
                    Path target = dir().resolve(name);
                    if (force || !Files.exists(target) || Files.size(target) != data.length) Files.write(target, data);
                }
            }
        } catch (Exception e) {
            Safe.note("Could not copy texture packs into the resourcepacks folder: " + e);
        }
        stamp = 0;
    }

    private static long stamp;
    private static final boolean[] HAVE = new boolean[FILES.length];

    /** Whether pack i is in the resourcepacks folder. Cached for two seconds so the settings screen can ask every frame. */
    static boolean installed(int i) {
        long now = System.currentTimeMillis();
        if (now - stamp > 2000) {
            stamp = now;
            Path d = dir();
            for (int k = 0; k < FILES.length; k++) HAVE[k] = Files.exists(d.resolve(FILES[k]));
        }
        return HAVE[Math.max(0, Math.min(FILES.length - 1, i))];
    }

    static int installedCount() {
        int n = 0;
        for (int i = 0; i < FILES.length; i++) if (installed(i)) n++;
        return n;
    }
}
